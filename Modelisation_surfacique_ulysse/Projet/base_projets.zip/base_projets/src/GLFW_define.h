#ifndef GLFW_KEY_A
#define 	GLFW_KEY_A   65
#endif

#ifndef GLFW_KEY_B
#define 	GLFW_KEY_B   66
#endif

#ifndef GLFW_KEY_C
#define 	GLFW_KEY_C   67
#endif

#ifndef GLFW_KEY_D
#define 	GLFW_KEY_D   68
#endif

#ifndef GLFW_KEY_E
#define 	GLFW_KEY_E   69
#endif

#ifndef GLFW_KEY_F
#define 	GLFW_KEY_F   70
#endif

#ifndef GLFW_KEY_G
#define 	GLFW_KEY_G   71
#endif

#ifndef GLFW_KEY_H
#define 	GLFW_KEY_H   72
#endif

#ifndef GLFW_KEY_I
#define 	GLFW_KEY_I   73
#endif

#ifndef GLFW_KEY_J
#define 	GLFW_KEY_J   74
#endif

#ifndef GLFW_KEY_K
#define 	GLFW_KEY_K   75
#endif

#ifndef GLFW_KEY_L
#define 	GLFW_KEY_L   76
#endif

#ifndef GLFW_KEY_M
#define 	GLFW_KEY_M   77
#endif

#ifndef GLFW_KEY_N
#define 	GLFW_KEY_N   78
#endif

#ifndef GLFW_KEY_O
#define 	GLFW_KEY_O   79
#endif

#ifndef GLFW_KEY_P
#define 	GLFW_KEY_P   80
#endif

#ifndef GLFW_KEY_Q
#define 	GLFW_KEY_Q   81
#endif

#ifndef GLFW_KEY_R
#define 	GLFW_KEY_R   82
#endif

#ifndef GLFW_KEY_S
#define 	GLFW_KEY_S   83
#endif

#ifndef GLFW_KEY_T
#define 	GLFW_KEY_T   84
#endif

#ifndef GLFW_KEY_U
#define 	GLFW_KEY_U   85
#endif

#ifndef GLFW_KEY_V
#define 	GLFW_KEY_V   86
#endif

#ifndef GLFW_KEY_W
#define 	GLFW_KEY_W   87
#endif

#ifndef GLFW_KEY_X
#define 	GLFW_KEY_X   88
#endif

#ifndef GLFW_KEY_Y
#define 	GLFW_KEY_Y   89
#endif

#ifndef GLFW_KEY_Z
#define 	GLFW_KEY_Z   90
#endif
